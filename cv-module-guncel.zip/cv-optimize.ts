import { GoogleGenerativeAI } from '@google/generative-ai'
import type { VercelRequest, VercelResponse } from '@vercel/node'
import type { OptimizedCvData, CvOptimizeRequest } from '../src/types/cv.js'
import { CV_SYSTEM_PROMPT } from '../src/lib/cvPrompt.js'

export const maxDuration = 60

function cleanMarkdown(obj: unknown): unknown {
  if (typeof obj === 'string') return obj.replace(/\*\*/g, '')
  if (Array.isArray(obj)) return obj.map(cleanMarkdown)
  if (obj && typeof obj === 'object') {
    return Object.fromEntries(
      Object.entries(obj as Record<string, unknown>).map(([k, v]) => [k, cleanMarkdown(v)])
    )
  }
  return obj
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' })

  const { cvText, jobDescription, language } = req.body as CvOptimizeRequest
  if (!cvText || cvText.length < 20) {
    return res.status(400).json({ error: 'CV metni çok kısa.' })
  }

  const apiKey = process.env.GEMINI_API_KEY
  if (!apiKey) return res.status(500).json({ error: 'GEMINI_API_KEY tanımlı değil.' })

  const langNote = language === 'tr'
    ? 'Tüm metin alanlarını TÜRKÇE yaz.'
    : 'Write ALL text fields in ENGLISH.'

  try {
    const genAI = new GoogleGenerativeAI(apiKey)
    const model = genAI.getGenerativeModel({
      model: 'gemini-2.5-flash',
      systemInstruction: CV_SYSTEM_PROMPT,
    })

    const privacyReminder = jobDescription
      ? `\n\n🚫 HATIRLATMA: İlan veren şirketin adı, iç programları veya iç sistem adları CV'nin HİÇBİR ALANINDA geçmeyecek. Özet ve deneyim maddeleri evrensel, transferable bir dille yazılacak.`
      : ''

    const userText = `${langNote}${privacyReminder}\n\nCV: ${cvText.slice(0, 8000)}\n\nİlan: ${(jobDescription || '').slice(0, 3000)}`
    const result = await model.generateContent({
      contents: [{ role: 'user', parts: [{ text: userText }] }],
      generationConfig: { maxOutputTokens: 4096, temperature: 0.3 },
    })

    let text = result.response.text()
    text = text.replace(/```json/g, '').replace(/```/g, '').trim()

    const parsed = JSON.parse(text) as { is_valid_cv?: boolean; error_message?: string } & OptimizedCvData

    if (parsed.is_valid_cv === false) {
      return res.status(400).json({ error: parsed.error_message })
    }

    if (Array.isArray(parsed.experience)) {
      parsed.experience = parsed.experience.map((e, i) => ({
        ...e,
        id: e.id || `exp-${i}-${Date.now()}`,
        bullets: e.bullets?.length ? e.bullets : (e.bullets_v1 ?? []),
      }))
    }
    if (Array.isArray(parsed.education)) {
      parsed.education = parsed.education.map((e, i) => ({
        ...e,
        id: e.id || `edu-${i}-${Date.now()}`,
      }))
    }

    const clean = cleanMarkdown(parsed) as OptimizedCvData
    return res.status(200).json(clean)
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err)
    console.error('CV optimize hatası:', msg)
    return res.status(500).json({ error: msg })
  }
}
