import { useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { Upload, X, AlertCircle, ChevronDown, ChevronUp, Download, RotateCcw } from 'lucide-react'
import mammoth from 'mammoth'
import * as pdfjsLib from 'pdfjs-dist'
import pdfjsWorker from 'pdfjs-dist/build/pdf.worker.min.mjs?url'
import { useAppStore } from '../../store/useAppStore'
import { useAuthStore } from '../../store/useAuthStore'
import { useCvStore } from '../../store/useCvStore'
import { CV_SYSTEM_PROMPT } from '../../lib/cvPrompt'
import { CvPreview, type CvPreviewHandle } from './CvPreview'
import type { TemplateId, PhotoShapeClass } from '../../types/cv'

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfjsWorker

// ── Constants ─────────────────────────────────────────────────────────────────
const MAX_FILE_BYTES = 5 * 1024 * 1024 // 5 MB

const TEMPLATE_LABELS: Record<TemplateId, string> = {
  modern: 'Modern', classic: 'Klasik', professional: 'Profesyonel', elegant: 'Zarif', bold: 'Güçlü',
}
const TEMPLATE_IDS: TemplateId[] = ['modern', 'classic', 'professional', 'elegant', 'bold']

const PRESET_COLORS = ['#c8c4bc', '#9e9b94', '#6b6760', '#37342f', '#111111']

const PHOTO_SHAPES: { value: PhotoShapeClass; label: string }[] = [
  { value: 'rounded-none', label: 'Kare' },
  { value: 'rounded-lg', label: 'Yuvarlatılmış' },
  { value: 'rounded-full', label: 'Daire' },
]

// ── Score color ────────────────────────────────────────────────────────────────
function scoreColor(n: number) {
  return n >= 70 ? '#10b981' : n >= 45 ? '#f59e0b' : '#ef4444'
}

// ── File text extractor ───────────────────────────────────────────────────────
async function extractFileText(file: File): Promise<string> {
  const ext = file.name.split('.').pop()?.toLowerCase() ?? ''
  if (!['pdf', 'doc', 'docx', 'txt'].includes(ext)) throw new Error('Desteklenmeyen format. PDF, Word veya TXT yükleyin.')
  if (file.size > MAX_FILE_BYTES) throw new Error('Dosya 5 MB\'dan büyük. Daha küçük bir dosya deneyin.')

  if (ext === 'pdf') {
    const buf = await file.arrayBuffer()
    const pdf = await pdfjsLib.getDocument({ data: buf }).promise
    const parts: string[] = []
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i)
      const content = await page.getTextContent()
      parts.push(content.items.map(it => ('str' in it ? it.str : '')).join(' '))
    }
    const text = parts.join('\n\n').trim()
    if (text.length < 20) throw new Error('PDF okunamadı (taranmış görsel olabilir). Word veya TXT deneyin.')
    return text
  }

  if (ext === 'docx' || ext === 'doc') {
    const buf = await file.arrayBuffer()
    const result = await mammoth.extractRawText({ arrayBuffer: buf })
    const text = result.value.trim()
    if (text.length < 20) throw new Error('Word dosyası okunamadı. PDF veya TXT formatında deneyin.')
    return text
  }

  // txt
  const text = (await file.text()).trim()
  if (text.length < 20) throw new Error('Dosyadan metin çıkarılamadı.')
  return text
}

// ── Main page ─────────────────────────────────────────────────────────────────
export function CvOlusturPage() {
  const theme = useAppStore(s => s.theme)
  const d = theme === 'dark'
  const user = useAuthStore(s => s.user)
  const authLoading = useAuthStore(s => s.loading)

  const {
    originalCV, cvFileName, jobDescription, optimizedData, cvLanguage, isLoading, error,
    activeTemplate, themeColor, narrativeVoice, profileImage, photoShape,
    photoSize, photoObjectX, photoObjectY, photoScale, photoPosX, photoPosY,
    showIcons, sectionsOrder, customHeadings,
    setOriginalCV, setJobDescription, setOptimizedData, updateOptimizedData, setCvLanguage,
    setLoading, setError, setActiveTemplate, setThemeColor, setNarrativeVoice,
    setProfileImage, setPhotoShape, setPhotoTransform, setPhotoPosition, resetSession,
  } = useCvStore()

  const cvPreviewRef = useRef<CvPreviewHandle>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const photoInputRef = useRef<HTMLInputElement>(null)

  const [pasteText, setPasteText] = useState('')
  const [pasteOpen, setPasteOpen] = useState(false)
  const [fileError, setFileError] = useState('')
  const [extracting, setExtracting] = useState(false)
  const [downloading, setDownloading] = useState(false)
  const [isDragging, setIsDragging] = useState(false)

  // ── Item add / delete ─────────────────────────────────────────────────────────
  function addExperience() {
    updateOptimizedData(prev => ({
      ...prev,
      experience: [...(prev.experience || []), {
        id: `exp-${Date.now()}`, role: 'Yeni Pozisyon', company: 'Şirket', date: '',
        bullets_v1: ['Görev açıklaması ekleyin.'], bullets_v3: ['Görev açıklaması ekleyin.'], bullets: [],
      }],
    }))
  }
  function deleteExperience(id: string) {
    updateOptimizedData(prev => ({ ...prev, experience: prev.experience.filter(e => e.id !== id) }))
  }
  function addEducation() {
    updateOptimizedData(prev => ({
      ...prev,
      education: [...(prev.education || []), {
        id: `edu-${Date.now()}`, degree: 'Bölüm / Sertifika', school: 'Okul / Kurum', date: '', details: '',
      }],
    }))
  }
  function deleteEducation(id: string) {
    updateOptimizedData(prev => ({ ...prev, education: prev.education.filter(e => e.id !== id) }))
  }
  function addSkill() {
    updateOptimizedData(prev => ({ ...prev, skills: [...(prev.skills || []), 'Yeni Beceri'] }))
  }
  function deleteSkill(idx: number) {
    updateOptimizedData(prev => ({ ...prev, skills: prev.skills.filter((_, i) => i !== idx) }))
  }
  function addAdditional() {
    updateOptimizedData(prev => ({ ...prev, additional: [...(prev.additional || []), 'Yeni Bilgi'] }))
  }
  function deleteAdditional(idx: number) {
    updateOptimizedData(prev => ({ ...prev, additional: prev.additional.filter((_, i) => i !== idx) }))
  }
  function handleAddBullet(expId: string) {
    updateOptimizedData(prev => ({
      ...prev,
      experience: prev.experience.map(exp => exp.id !== expId ? exp : {
        ...exp,
        bullets_v1: [...exp.bullets_v1, 'Yeni görev maddesi.'],
        bullets_v3: [...exp.bullets_v3, 'Yeni görev maddesi.'],
      }),
    }))
  }
  function handleDeleteBullet(expId: string, bulletIdx: number) {
    updateOptimizedData(prev => ({
      ...prev,
      experience: prev.experience.map(exp => exp.id !== expId ? exp : {
        ...exp,
        bullets_v1: exp.bullets_v1.filter((_, i) => i !== bulletIdx),
        bullets_v3: exp.bullets_v3.filter((_, i) => i !== bulletIdx),
      }),
    }))
  }

  // ── Style vars ───────────────────────────────────────────────────────────────
  const bg       = d ? '#0d1117' : '#f8fafc'
  const surface  = d ? 'rgba(255,255,255,0.04)' : '#ffffff'
  const border   = d ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)'
  const text      = d ? '#f1f5f9' : '#0f172a'
  const muted    = d ? '#64748b' : '#94a3b8'
  const inputBg  = d ? 'rgba(255,255,255,0.05)' : '#ffffff'
  const inputBdr = d ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.12)'

  // ── File upload handler ──────────────────────────────────────────────────────
  async function handleFile(file: File) {
    setFileError('')
    setExtracting(true)
    setPasteText('')
    try {
      const text = await extractFileText(file)
      setOriginalCV(text, file.name)
    } catch (e) {
      setFileError(e instanceof Error ? e.message : String(e))
    } finally {
      setExtracting(false)
    }
  }

  // ── Optimize ─────────────────────────────────────────────────────────────────
  async function handleOptimize() {
    const cvText = originalCV || pasteText
    if (cvText.length < 20) { setError('CV metni çok kısa.'); return }
    if (!originalCV && pasteText.length >= 20) setOriginalCV(pasteText, 'Manuel giriş')
    setLoading(true)
    setError(null)
    try {
      // DEV MODE: tarayıcıdan doğrudan Gemini çağrısı (sunucu gerekmez)
      if (import.meta.env.DEV) {
        const apiKey = import.meta.env.VITE_GEMINI_API_KEY
        if (!apiKey) throw new Error('VITE_GEMINI_API_KEY .env dosyasına eklenmemiş. GEMINI_API_KEY değerini VITE_ önekiyle kopyalayın.')
        const { GoogleGenerativeAI } = await import('@google/generative-ai')
        const model = new GoogleGenerativeAI(apiKey).getGenerativeModel({
          model: 'gemini-2.5-flash-lite',
          systemInstruction: CV_SYSTEM_PROMPT,
        })
        const langNote = cvLanguage === 'tr' ? 'Tüm metin alanlarını TÜRKÇE yaz.' : 'Write ALL text fields in ENGLISH.'
        const result = await model.generateContent({
          contents: [{ role: 'user', parts: [{ text: `${langNote}\n\nCV: ${cvText.slice(0, 8000)}\n\nİlan: ${(jobDescription || '').slice(0, 3000)}` }] }],
          generationConfig: { maxOutputTokens: 4096, temperature: 0.3 },
        })
        let text = result.response.text().replace(/```json/g, '').replace(/```/g, '').trim()
        const parsed = JSON.parse(text) as Record<string, unknown>
        if (parsed.is_valid_cv === false) throw new Error(parsed.error_message as string)
        if (Array.isArray(parsed.experience)) {
          parsed.experience = (parsed.experience as Record<string, unknown>[]).map((e, i) => ({
            ...e, id: e.id || `exp-${i}-${Date.now()}`,
            bullets: Array.isArray(e.bullets) && (e.bullets as unknown[]).length ? e.bullets : (e.bullets_v1 ?? []),
          }))
        }
        if (Array.isArray(parsed.education)) {
          parsed.education = (parsed.education as Record<string, unknown>[]).map((e, i) => ({ ...e, id: e.id || `edu-${i}-${Date.now()}` }))
        }
        setOptimizedData(parsed as never)
        return
      }

      // PRODUCTION: Vercel serverless API route
      const res = await fetch('/api/cv-optimize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cvText, jobDescription: jobDescription || '', language: cvLanguage }),
      })
      const rawText = await res.text()
      let json: Record<string, unknown>
      try {
        json = JSON.parse(rawText)
      } catch {
        throw new Error(`Sunucu geçersiz yanıt döndürdü (HTTP ${res.status}). Lütfen tekrar deneyin.`)
      }
      if (!res.ok) throw new Error((json.error as string) || 'Optimizasyon başarısız.')
      setOptimizedData(json as never)
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    } finally {
      setLoading(false)
    }
  }

  // ── PDF download ─────────────────────────────────────────────────────────────
  async function handleDownload() {
    if (!cvPreviewRef.current) { alert('Önizleme yüklenemedi, lütfen sayfayı yenileyin.'); return }
    setDownloading(true)
    try {
      await cvPreviewRef.current.downloadPdf()
    } catch (err) {
      console.error('PDF hatası:', err)
      alert(`PDF oluşturulamadı: ${err instanceof Error ? err.message : String(err)}`)
    } finally {
      setDownloading(false)
    }
  }

  // ── Photo upload ─────────────────────────────────────────────────────────────
  function handlePhotoFile(file: File) {
    if (!file.type.startsWith('image/')) return
    const reader = new FileReader()
    reader.onload = e => setProfileImage(e.target?.result as string)
    reader.readAsDataURL(file)
  }

  // ── Auth guards ───────────────────────────────────────────────────────────────
  if (authLoading) return (
    <div style={{ minHeight: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center', background: bg }}>
      <div style={{ width: 32, height: 32, border: '3px solid rgba(99,102,241,0.2)', borderTopColor: '#6366f1', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
      <style>{`@keyframes spin{to{transform:rotate(360deg)}} @keyframes fadeUp{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}}`}</style>
    </div>
  )

  if (!user) return (
    <div style={{ minHeight: 'calc(100vh - 64px)', display: 'flex', justifyContent: 'center', alignItems: 'center', padding: '0 16px', background: bg }}>
      <div style={{ maxWidth: 440, textAlign: 'center' }}>
        <div style={{ fontSize: 52, marginBottom: 16 }}>📄</div>
        <h2 style={{ color: text, fontSize: 22, fontWeight: 700, marginBottom: 10 }}>CV Oluştur & Optimize</h2>
        <p style={{ color: muted, fontSize: 14, marginBottom: 28, lineHeight: 1.6 }}>Bu özelliği kullanmak için giriş yapman gerekiyor.</p>
        <Link to="/giris" style={{ display: 'inline-block', padding: '12px 28px', borderRadius: 10, background: 'linear-gradient(135deg,#6366f1,#8b5cf6)', color: '#fff', textDecoration: 'none', fontWeight: 700, fontSize: 14 }}>
          Giriş Yap
        </Link>
      </div>
    </div>
  )

  // ── Loading screen ────────────────────────────────────────────────────────────
  if (isLoading) return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}
      style={{ minHeight: 'calc(100vh - 64px)', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', gap: 16, background: bg }}
    >
      <style>{`@keyframes spin{to{transform:rotate(360deg)}} @keyframes pulse{0%,100%{opacity:1}50%{opacity:0.5}}`}</style>
      <div style={{ position: 'relative', width: 72, height: 72 }}>
        <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', border: '3px solid rgba(99,102,241,0.12)' }} />
        <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', border: '3px solid transparent', borderTopColor: '#6366f1', borderRightColor: 'rgba(99,102,241,0.4)', animation: 'spin 0.9s linear infinite' }} />
        <div style={{ position: 'absolute', inset: 10, borderRadius: '50%', border: '2px solid transparent', borderTopColor: '#8b5cf6', animation: 'spin 0.6s linear infinite reverse' }} />
      </div>
      <div style={{ textAlign: 'center' }}>
        <p style={{ color: text, fontSize: 15, fontWeight: 700, marginBottom: 6 }}>CV optimize ediliyor…</p>
        <p style={{ color: muted, fontSize: 13 }}>Yapay zeka CV'nizi analiz ediyor, bu 15–30 saniye sürebilir.</p>
      </div>
      <div style={{ display: 'flex', gap: 6, marginTop: 4 }}>
        {[0, 0.2, 0.4].map(delay => (
          <div key={delay} style={{ width: 7, height: 7, borderRadius: '50%', background: '#6366f1', animation: `pulse 1.2s ease-in-out ${delay}s infinite` }} />
        ))}
      </div>
    </motion.div>
  )

  // ── Upload screen ──────────────────────────────────────────────────────────────
  if (!optimizedData) {
    const effectiveCv = originalCV || pasteText
    const canOptimize = effectiveCv.length >= 20

    return (
      <motion.div
        initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, ease: 'easeOut' }}
        style={{ minHeight: 'calc(100vh - 64px)', background: bg, padding: '32px 16px' }}
      >
        <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
        <div style={{ maxWidth: 640, margin: '0 auto' }}>
          {/* Title */}
          <div style={{ textAlign: 'center', marginBottom: 32 }}>
            <div style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: 52, height: 52, borderRadius: 16, background: d ? 'rgba(99,102,241,0.15)' : 'rgba(99,102,241,0.1)', marginBottom: 14 }}>
              <span style={{ fontSize: 24 }}>📄</span>
            </div>
            <h1 style={{ fontSize: 28, fontWeight: 800, color: text, marginBottom: 8 }}>CV Oluştur & Optimize</h1>
            <p style={{ fontSize: 14, color: muted, lineHeight: 1.6 }}>CV'nizi yükleyin, opsiyonel iş ilanı ekleyin. Yapay zeka analiz edip ATS skoru ve optimize edilmiş CV hazırlasın.</p>
          </div>

          {/* CV Upload area */}
          <div style={{ marginBottom: 20 }}>
            <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: text, marginBottom: 8 }}>CV Dosyanız <span style={{ color: '#ef4444' }}>*</span></label>
            <div
              onClick={() => !extracting && fileInputRef.current?.click()}
              onDrop={e => { e.preventDefault(); setIsDragging(false); const f = e.dataTransfer.files[0]; if (f) handleFile(f) }}
              onDragOver={e => { e.preventDefault(); setIsDragging(true) }}
              onDragLeave={() => setIsDragging(false)}
              onDragEnd={() => setIsDragging(false)}
              style={{
                border: isDragging
                  ? '2px dashed #6366f1'
                  : originalCV
                  ? '2px solid #10b981'
                  : fileError
                  ? '2px dashed #ef4444'
                  : `2px dashed ${border}`,
                borderRadius: 14,
                padding: 24,
                textAlign: 'center',
                cursor: extracting ? 'wait' : 'pointer',
                transition: 'all 0.2s',
                background: isDragging
                  ? d ? 'rgba(99,102,241,0.08)' : 'rgba(99,102,241,0.04)'
                  : originalCV
                  ? d ? 'rgba(16,185,129,0.06)' : 'rgba(16,185,129,0.03)'
                  : surface,
                transform: isDragging ? 'scale(1.01)' : 'scale(1)',
              }}
            >
              <input ref={fileInputRef} type="file" accept=".pdf,.doc,.docx,.txt" style={{ display: 'none' }} onChange={e => e.target.files?.[0] && handleFile(e.target.files[0])} />
              {extracting ? (
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
                  <div style={{ width: 28, height: 28, borderRadius: '50%', border: '3px solid rgba(99,102,241,0.2)', borderTopColor: '#6366f1', animation: 'spin 0.8s linear infinite' }} />
                  <p style={{ fontSize: 13, color: muted }}>CV okunuyor…</p>
                </div>
              ) : originalCV ? (
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
                  <span style={{ fontSize: 28 }}>✅</span>
                  <p style={{ fontSize: 13, fontWeight: 700, color: '#10b981' }}>{cvFileName || 'CV yüklendi'}</p>
                  <p style={{ fontSize: 12, color: muted }}>{originalCV.length.toLocaleString('tr-TR')} karakter</p>
                  <button onClick={e => { e.stopPropagation(); setOriginalCV('', ''); setFileError('') }}
                    style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 12, color: '#ef4444', background: 'transparent', border: 'none', cursor: 'pointer' }}>
                    <X size={14} /> Kaldır
                  </button>
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 }}>
                  <div style={{ width: 40, height: 40, borderRadius: 12, background: d ? 'rgba(99,102,241,0.15)' : 'rgba(99,102,241,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Upload size={20} style={{ color: '#6366f1' }} />
                  </div>
                  <div>
                    <p style={{ fontSize: 13, fontWeight: 600, color: text, marginBottom: 2 }}>CV'nizi sürükleyin veya seçin</p>
                    <p style={{ fontSize: 12, color: muted }}>PDF, Word (.docx) veya TXT • Maks. 5 MB</p>
                  </div>
                </div>
              )}
            </div>
            {fileError && <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 8, fontSize: 13, color: '#ef4444' }}><AlertCircle size={14} />{fileError}</div>}
          </div>

          {/* Paste toggle */}
          <div style={{ marginBottom: 20 }}>
            <button onClick={() => setPasteOpen(v => !v)}
              style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, fontWeight: 600, color: muted, background: 'transparent', border: 'none', cursor: 'pointer', padding: 0 }}>
              {pasteOpen ? <ChevronUp size={14} /> : <ChevronDown size={14} />} CV metnini yapıştırmak istiyorum
            </button>
            {pasteOpen && (
              <div style={{ marginTop: 8 }}>
                <textarea value={pasteText} onChange={e => { setPasteText(e.target.value); if (originalCV) setOriginalCV('', '') }}
                  placeholder="CV içeriğinizi buraya yapıştırın…"
                  rows={6}
                  style={{ width: '100%', boxSizing: 'border-box', padding: '10px 14px', borderRadius: 12, border: `1px solid ${inputBdr}`, background: inputBg, color: text, fontSize: 13, lineHeight: 1.65, fontFamily: 'inherit', outline: 'none', resize: 'vertical' }} />
                {pasteText.length > 0 && <p style={{ fontSize: 12, color: '#10b981', marginTop: 4 }}>✓ {pasteText.length.toLocaleString('tr-TR')} karakter</p>}
              </div>
            )}
          </div>

          {/* Job description (optional) */}
          <div style={{ marginBottom: 20 }}>
            <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: text, marginBottom: 4 }}>
              İş İlanı <span style={{ fontSize: 12, fontWeight: 400, color: muted }}>(opsiyonel — ATS skoru için)</span>
            </label>
            <textarea value={jobDescription} onChange={e => setJobDescription(e.target.value.slice(0, 3000))}
              placeholder="Başvurduğunuz pozisyona ait iş tanımını yapıştırın…"
              rows={4}
              style={{ width: '100%', boxSizing: 'border-box', padding: '10px 14px', borderRadius: 12, border: `1px solid ${inputBdr}`, background: inputBg, color: text, fontSize: 13, lineHeight: 1.65, fontFamily: 'inherit', outline: 'none', resize: 'vertical' }} />
            <div style={{ display: 'flex', justifyContent: 'flex-end', fontSize: 12, color: muted, marginTop: 4 }}>{jobDescription.length} / 3000</div>
          </div>

          {/* Language + Optimize */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
            <div style={{ display: 'flex', gap: 6 }}>
              <span style={{ fontSize: 13, color: muted, fontWeight: 600, alignSelf: 'center' }}>Dil:</span>
              {(['tr', 'en'] as const).map(lang => (
                <button key={lang} onClick={() => setCvLanguage(lang)}
                  style={{ padding: '6px 14px', borderRadius: 8, background: cvLanguage === lang ? '#6366f1' : 'transparent', color: cvLanguage === lang ? '#fff' : muted, border: `1px solid ${cvLanguage === lang ? '#6366f1' : border}`, cursor: 'pointer', fontWeight: 600, fontSize: 13, transition: 'all 0.15s' }}>
                  {lang.toUpperCase()}
                </button>
              ))}
            </div>
            <button onClick={handleOptimize} disabled={!canOptimize}
              style={{ flex: 1, minWidth: 200, padding: '12px 28px', borderRadius: 12, fontSize: 14, fontWeight: 700, border: 'none', cursor: canOptimize ? 'pointer' : 'not-allowed', background: canOptimize ? 'linear-gradient(135deg,#6366f1,#8b5cf6)' : (d ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)'), color: canOptimize ? '#fff' : muted, boxShadow: canOptimize ? '0 8px 24px rgba(99,102,241,0.3)' : 'none', transition: 'all 0.2s' }}>
              ✨ CV Optimize Et
            </button>
          </div>

          {/* Error */}
          <AnimatePresence>
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.25 }}
                style={{ marginTop: 16, padding: '12px 16px', borderRadius: 12, background: d ? 'rgba(239,68,68,0.1)' : 'rgba(239,68,68,0.05)', border: '1px solid rgba(239,68,68,0.2)', color: '#ef4444', fontSize: 13 }}
              >
                {error}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    )
  }

  // ── Editor layout ──────────────────────────────────────────────────────────────
  const analysis = optimizedData.analysis

  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.35 }}
      style={{ minHeight: 'calc(100vh - 64px)', paddingTop: 64, background: bg, display: 'flex', flexDirection: 'column' }}
    >
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>

      {/* Top bar */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 20px', background: surface, borderBottom: `1px solid ${border}`, gap: 12, flexWrap: 'wrap', position: 'relative', zIndex: 10 }}>
        <div>
          <h1 style={{ fontSize: 16, fontWeight: 800, color: text, marginBottom: 1 }}>CV Düzenleyici</h1>
          <p style={{ fontSize: 12, color: muted }}>Alanları tıklayarak doğrudan düzenleyebilirsiniz.</p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button onClick={() => { if (confirm('CV oturumunu sıfırlamak istediğinizden emin misiniz?')) { resetSession(); setPasteText('') } }}
            style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 14px', borderRadius: 8, border: `1px solid ${border}`, background: 'transparent', color: muted, cursor: 'pointer', fontSize: 13, fontWeight: 600 }}>
            <RotateCcw size={14} /> Yeni CV
          </button>
          <button onClick={handleDownload} disabled={downloading}
            style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 18px', borderRadius: 8, border: 'none', background: 'linear-gradient(135deg,#6366f1,#8b5cf6)', color: '#fff', cursor: downloading ? 'wait' : 'pointer', fontSize: 13, fontWeight: 700, boxShadow: '0 4px 14px rgba(99,102,241,0.3)' }}>
            <Download size={14} /> {downloading ? 'Hazırlanıyor…' : 'PDF İndir'}
          </button>
        </div>
      </div>

      {/* Two panels */}
      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>

        {/* ── Left panel ── */}
        <div style={{ width: 280, flexShrink: 0, background: surface, borderRight: `1px solid ${border}`, overflowY: 'auto', padding: '16px 14px', display: 'flex', flexDirection: 'column', gap: 16 }}>

          {/* Template */}
          <div>
            <p style={{ fontSize: 11, fontWeight: 700, color: muted, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 8 }}>Şablon</p>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
              {TEMPLATE_IDS.map(tpl => (
                <button key={tpl} onClick={() => setActiveTemplate(tpl)}
                  style={{ padding: '7px 4px', borderRadius: 8, border: `2px solid ${activeTemplate === tpl ? '#6366f1' : border}`, background: activeTemplate === tpl ? (d ? 'rgba(99,102,241,0.15)' : 'rgba(99,102,241,0.08)') : 'transparent', color: activeTemplate === tpl ? '#6366f1' : text, cursor: 'pointer', fontSize: 12, fontWeight: 600, transition: 'all 0.15s', textAlign: 'center' }}>
                  {TEMPLATE_LABELS[tpl]}
                </button>
              ))}
            </div>
          </div>

          {/* Color */}
          <div>
            <p style={{ fontSize: 11, fontWeight: 700, color: muted, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 8 }}>Renk</p>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 8 }}>
              {PRESET_COLORS.map(c => (
                <button key={c} onClick={() => setThemeColor(c)}
                  style={{ width: 24, height: 24, borderRadius: '50%', background: c, border: `2px solid ${themeColor === c ? '#fff' : 'transparent'}`, outline: themeColor === c ? `2px solid ${c}` : 'none', cursor: 'pointer', transition: 'all 0.15s' }} />
              ))}
            </div>
            <input type="color" value={themeColor} onChange={e => setThemeColor(e.target.value)}
              style={{ width: '100%', height: 32, borderRadius: 8, border: `1px solid ${border}`, cursor: 'pointer', background: 'transparent' }} />
          </div>

          {/* Voice */}
          <div>
            <p style={{ fontSize: 11, fontWeight: 700, color: muted, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 8 }}>Ses Tonu</p>
            <div style={{ display: 'flex', gap: 6 }}>
              {([['first', '1. Şahıs (Ben)'], ['third', '3. Şahıs (O)']] as const).map(([v, lbl]) => (
                <button key={v} onClick={() => setNarrativeVoice(v)}
                  style={{ flex: 1, padding: '7px 6px', borderRadius: 8, border: `2px solid ${narrativeVoice === v ? '#6366f1' : border}`, background: narrativeVoice === v ? (d ? 'rgba(99,102,241,0.15)' : 'rgba(99,102,241,0.08)') : 'transparent', color: narrativeVoice === v ? '#6366f1' : text, cursor: 'pointer', fontSize: 11, fontWeight: 600 }}>
                  {lbl}
                </button>
              ))}
            </div>
          </div>

          {/* Photo */}
          <div>
            <p style={{ fontSize: 11, fontWeight: 700, color: muted, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 8 }}>Fotoğraf</p>
            <input ref={photoInputRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={e => e.target.files?.[0] && handlePhotoFile(e.target.files[0])} />
            {profileImage ? (
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                <img src={profileImage} alt="" style={{ width: 44, height: 44, borderRadius: photoShape === 'rounded-full' ? '50%' : photoShape === 'rounded-none' ? 4 : 8, objectFit: 'cover', border: `1px solid ${border}` }} />
                <div style={{ display: 'flex', gap: 6 }}>
                  <button onClick={() => photoInputRef.current?.click()} style={{ fontSize: 11, color: '#6366f1', background: 'transparent', border: 'none', cursor: 'pointer', fontWeight: 600 }}>Değiştir</button>
                  <button onClick={() => setProfileImage(null)} style={{ fontSize: 11, color: '#ef4444', background: 'transparent', border: 'none', cursor: 'pointer' }}>Kaldır</button>
                </div>
              </div>
            ) : (
              <button onClick={() => photoInputRef.current?.click()}
                style={{ width: '100%', padding: '10px', borderRadius: 10, border: `1.5px dashed ${border}`, background: 'transparent', color: muted, cursor: 'pointer', fontSize: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, marginBottom: 8 }}>
                + Fotoğraf Ekle
              </button>
            )}
            {(activeTemplate === 'modern' || activeTemplate === 'professional') && (
              <>
                <div style={{ display: 'flex', gap: 5, marginBottom: profileImage ? 10 : 0 }}>
                  {PHOTO_SHAPES.map(s => (
                    <button key={s.value} onClick={() => setPhotoShape(s.value)}
                      style={{ flex: 1, padding: '5px 2px', fontSize: 10, fontWeight: 600, borderRadius: 6, border: `1.5px solid ${photoShape === s.value ? '#6366f1' : border}`, background: photoShape === s.value ? (d ? 'rgba(99,102,241,0.15)' : 'rgba(99,102,241,0.08)') : 'transparent', color: photoShape === s.value ? '#6366f1' : muted, cursor: 'pointer' }}>
                      {s.label}
                    </button>
                  ))}
                </div>
                {profileImage && (
                  <div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                      <span style={{ fontSize: 10, fontWeight: 600, color: muted }}>Fotoğraf Boyutu</span>
                      <span style={{ fontSize: 10, color: muted }}>{Math.round(photoSize)}px</span>
                    </div>
                    <input
                      type="range" min={50} max={150} step={1}
                      value={photoSize}
                      onChange={e => setPhotoTransform(Number(e.target.value), photoObjectX, photoObjectY, photoScale)}
                      style={{ width: '100%', accentColor: '#6366f1', cursor: 'pointer' }}
                    />
                  </div>
                )}
              </>
            )}
          </div>

          {/* Item Management */}
          <div>
            <p style={{ fontSize: 11, fontWeight: 700, color: muted, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 10 }}>İçerik Yönetimi</p>

            {/* Experience */}
            <div style={{ marginBottom: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 5 }}>
                <span style={{ fontSize: 11, fontWeight: 700, color: text }}>Deneyim ({optimizedData.experience?.length ?? 0})</span>
                <button onClick={addExperience} style={{ fontSize: 11, color: '#6366f1', background: 'transparent', border: 'none', cursor: 'pointer', fontWeight: 700, padding: 0 }}>+ Ekle</button>
              </div>
              {optimizedData.experience?.map(exp => (
                <div key={exp.id} style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '3px 8px', borderRadius: 6, background: d ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.03)', marginBottom: 3 }}>
                  <span style={{ flex: 1, fontSize: 10, color: muted, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{exp.role || 'Pozisyon'} · {exp.company || 'Şirket'}</span>
                  <button onClick={() => deleteExperience(exp.id)} title="Sil" style={{ fontSize: 14, color: '#ef4444', background: 'transparent', border: 'none', cursor: 'pointer', flexShrink: 0, padding: 0, opacity: 0.6 }}>×</button>
                </div>
              ))}
            </div>

            {/* Education */}
            <div style={{ marginBottom: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 5 }}>
                <span style={{ fontSize: 11, fontWeight: 700, color: text }}>Eğitim ({optimizedData.education?.length ?? 0})</span>
                <button onClick={addEducation} style={{ fontSize: 11, color: '#6366f1', background: 'transparent', border: 'none', cursor: 'pointer', fontWeight: 700, padding: 0 }}>+ Ekle</button>
              </div>
              {optimizedData.education?.map(edu => (
                <div key={edu.id} style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '3px 8px', borderRadius: 6, background: d ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.03)', marginBottom: 3 }}>
                  <span style={{ flex: 1, fontSize: 10, color: muted, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{edu.degree || 'Bölüm'}</span>
                  <button onClick={() => deleteEducation(edu.id)} title="Sil" style={{ fontSize: 14, color: '#ef4444', background: 'transparent', border: 'none', cursor: 'pointer', flexShrink: 0, padding: 0, opacity: 0.6 }}>×</button>
                </div>
              ))}
            </div>

            {/* Skills */}
            <div style={{ marginBottom: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 5 }}>
                <span style={{ fontSize: 11, fontWeight: 700, color: text }}>Beceriler ({optimizedData.skills?.length ?? 0})</span>
                <button onClick={addSkill} style={{ fontSize: 11, color: '#6366f1', background: 'transparent', border: 'none', cursor: 'pointer', fontWeight: 700, padding: 0 }}>+ Ekle</button>
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                {optimizedData.skills?.map((skill, si) => (
                  <div key={si} style={{ display: 'flex', alignItems: 'center', gap: 2, padding: '2px 6px', borderRadius: 20, background: d ? 'rgba(99,102,241,0.1)' : 'rgba(99,102,241,0.07)', border: '1px solid rgba(99,102,241,0.2)' }}>
                    <span style={{ fontSize: 10, color: '#6366f1' }}>{skill}</span>
                    <button onClick={() => deleteSkill(si)} style={{ fontSize: 12, color: '#ef4444', background: 'transparent', border: 'none', cursor: 'pointer', padding: 0, lineHeight: 1, opacity: 0.6 }}>×</button>
                  </div>
                ))}
              </div>
            </div>

            {/* Additional */}
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 5 }}>
                <span style={{ fontSize: 11, fontWeight: 700, color: text }}>Ek Bilgiler ({optimizedData.additional?.length ?? 0})</span>
                <button onClick={addAdditional} style={{ fontSize: 11, color: '#6366f1', background: 'transparent', border: 'none', cursor: 'pointer', fontWeight: 700, padding: 0 }}>+ Ekle</button>
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                {optimizedData.additional?.map((item, ai) => (
                  <div key={ai} style={{ display: 'flex', alignItems: 'center', gap: 2, padding: '2px 6px', borderRadius: 20, background: d ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.04)', border: `1px solid ${border}` }}>
                    <span style={{ fontSize: 10, color: muted }}>{item}</span>
                    <button onClick={() => deleteAdditional(ai)} style={{ fontSize: 12, color: '#ef4444', background: 'transparent', border: 'none', cursor: 'pointer', padding: 0, lineHeight: 1, opacity: 0.6 }}>×</button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* ATS Panel */}
          {analysis && (
            <div>
              <p style={{ fontSize: 11, fontWeight: 700, color: muted, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 10 }}>ATS Raporu</p>
              {/* Scores */}
              <div style={{ marginBottom: 10, padding: '10px 12px', borderRadius: 10, border: `1px solid ${border}`, background: d ? 'rgba(255,255,255,0.02)' : 'rgba(0,0,0,0.02)', textAlign: 'center' }}>
                <div style={{ fontSize: 28, fontWeight: 900, color: scoreColor(analysis.scores.overall) }}>{analysis.scores.overall}</div>
                <div style={{ fontSize: 10, color: muted, marginBottom: 8 }}>Genel Uyum Skoru</div>
                {Object.entries({ skills: 'Beceri', experience: 'Deneyim', education: 'Eğitim' } as const).map(([k, lbl]) => (
                  <div key={k} style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                    <span style={{ fontSize: 10, color: muted, width: 52, textAlign: 'left', flexShrink: 0 }}>{lbl}</span>
                    <div style={{ flex: 1, height: 4, borderRadius: 4, background: d ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)', overflow: 'hidden' }}>
                      <div style={{ height: '100%', width: `${analysis.scores[k as keyof typeof analysis.scores]}%`, background: scoreColor(analysis.scores[k as keyof typeof analysis.scores]), borderRadius: 4, transition: 'width 0.6s ease' }} />
                    </div>
                    <span style={{ fontSize: 10, fontWeight: 700, color: scoreColor(analysis.scores[k as keyof typeof analysis.scores]), width: 24, textAlign: 'right', flexShrink: 0 }}>{analysis.scores[k as keyof typeof analysis.scores]}</span>
                  </div>
                ))}
              </div>
              {/* Matched skills */}
              {(analysis.matches.hard_skills.length + analysis.matches.soft_skills.length) > 0 && (
                <div style={{ marginBottom: 8 }}>
                  <p style={{ fontSize: 10, fontWeight: 700, color: '#10b981', marginBottom: 5 }}>✓ Eşleşen Beceriler</p>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                    {[...analysis.matches.hard_skills, ...analysis.matches.soft_skills].slice(0, 10).map((s, i) => (
                      <span key={i} style={{ fontSize: 10, padding: '2px 7px', borderRadius: 20, background: d ? 'rgba(16,185,129,0.15)' : 'rgba(16,185,129,0.1)', color: '#10b981' }}>{s}</span>
                    ))}
                  </div>
                </div>
              )}
              {/* Gaps */}
              {analysis.gaps?.length > 0 && (
                <div>
                  <p style={{ fontSize: 10, fontWeight: 700, color: '#f59e0b', marginBottom: 5 }}>⚠ Eksik Alanlar</p>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                    {analysis.gaps.slice(0, 6).map((g, i) => (
                      <span key={i} style={{ fontSize: 10, padding: '2px 7px', borderRadius: 20, background: d ? 'rgba(245,158,11,0.12)' : 'rgba(245,158,11,0.1)', color: '#f59e0b' }}>{g}</span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Warnings Panel */}
          {optimizedData.warnings && optimizedData.warnings.length > 0 && (
            <div>
              <p style={{ fontSize: 11, fontWeight: 700, color: muted, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 8 }}>Öneriler</p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {optimizedData.warnings.map((w, i) => {
                  const isHigh = w.severity === 'high'
                  const isMed  = w.severity === 'medium'
                  const accent = isHigh ? '#ef4444' : isMed ? '#f59e0b' : '#6366f1'
                  const bg     = isHigh
                    ? (d ? 'rgba(239,68,68,0.08)' : 'rgba(239,68,68,0.06)')
                    : isMed
                    ? (d ? 'rgba(245,158,11,0.08)' : 'rgba(245,158,11,0.06)')
                    : (d ? 'rgba(99,102,241,0.08)' : 'rgba(99,102,241,0.06)')
                  return (
                    <div key={i} style={{ padding: '8px 10px', borderRadius: 8, border: `1px solid ${accent}30`, background: bg, display: 'flex', gap: 8, alignItems: 'flex-start' }}>
                      <span style={{ fontSize: 13, flexShrink: 0, lineHeight: 1 }}>
                        {isHigh ? '🔴' : isMed ? '🟡' : '🔵'}
                      </span>
                      <p style={{ fontSize: 10.5, color: text, lineHeight: 1.45, margin: 0, flex: 1 }}>{w.message}</p>
                    </div>
                  )
                })}
              </div>
            </div>
          )}
        </div>

        {/* ── Right panel — Preview ── */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '20px', background: d ? '#0a0e17' : '#e8edf3', display: 'flex', flexDirection: 'column', gap: 16 }}>
          <CvPreview
            ref={cvPreviewRef}
            data={optimizedData}
            template={activeTemplate}
            themeColor={themeColor}
            narrativeVoice={narrativeVoice}
            textAlign="text-left"
            profileImage={profileImage}
            photoShape={photoShape}
            photoSize={photoSize}
            photoObjectX={photoObjectX}
            photoObjectY={photoObjectY}
            photoScale={photoScale}
            photoPosX={photoPosX}
            photoPosY={photoPosY}
            onPhotoChange={(sz, x, y, sc) => setPhotoTransform(sz, x, y, sc)}
            onPhotoPosChange={(x, y) => setPhotoPosition(x, y)}
            showIcons={showIcons}
            cvLanguage={cvLanguage}
            sectionsOrder={sectionsOrder}
            customHeadings={customHeadings}
            onUpdate={updateOptimizedData}
            onAddBullet={handleAddBullet}
            onDeleteBullet={handleDeleteBullet}
          />
        </div>
      </div>
    </motion.div>
  )
}
